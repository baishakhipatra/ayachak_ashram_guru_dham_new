@extends('admin.layouts.app')

@section('page', 'Banner detail')

@section('content')
<section>
    <div class="row">
        <div class="col-sm-8">
            <div class="card">    
                <div class="card-body">
                     <h4 class="page__subtitle">Desktop Banner</h4>
                    <div class="row">
                        <div class="col-md-12">
                            @if ($data->type == 'video')
                                <video id="onn-video" style="width: 100%" autoplay muted loop controls playsinline>
                                    <source src="{{ asset($data->file_path) }}" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            @else
                                <img src="{{ asset($data->file_path) }}" class="w-100"/>
                            @endif
                        </div>
                    </div>  
                     <h4 class="page__subtitle">Mobile Banner</h4>
                    <div class="row">
                        <div class="col-md-12">
                            @if ($data->type == 'video')
                                <video id="onn-video" style="width: 100%" autoplay muted loop controls playsinline>
                                    <source src="{{ asset($data->file_path) }}" type="video/mp4">
                                    Your browser does not support the video tag.
                                </video>
                            @else
                                <img src="{{ asset($data->mobile_image_path) }}" class="w-100"/>
                            @endif
                        </div>
                    </div> 
                </div>
            </div>
        </div>

        <div class="col-sm-4">
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.banner.update', $data->id) }}" enctype="multipart/form-data">@csrf
                        <h4 class="page__subtitle">Edit</h4>
                        <div class="row">
                            <div class="col-md-12 card">
                                <div class="card-header p-0 mb-3">Desktop Image <span class="text-danger">*</span></div>
                                <div class="card-body p-0">
                                    <div class="w-100 product__thumb">
                                        <label for="icon"><img id="iconOutput" src="{{ asset('admin/images/placeholder-image.jpg') }}" /></label>
                                    </div>
                                    <input type="file" name="image" id="icon" accept="image/*" onchange="loadIcon(event)" class="d-none">
                                    <p class="small text-muted">Click here to browse image</p>

                                    <script>
                                        let loadIcon = function(event) {
                                            let iconOutput = document.getElementById('iconOutput');
                                            iconOutput.src = URL.createObjectURL(event.target.files[0]);
                                            iconOutput.onload = function() {
                                                URL.revokeObjectURL(iconOutput.src) // free memory
                                            }
                                        };
                                    </script>
                                </div>
                                @error('image') <p class="small text-danger">{{ $message }}</p> @enderror
                            </div>
                            <div class="col-md-12 card">
                                <div class="card-header p-0 mb-3">Mobile Image <span class="text-danger">*</span></div>
                                <div class="card-body p-0">
                                    <div class="w-100 product__thumb">
                                        <label for="mobile_icon"><img id="mobileiconOutput" src="{{ asset('admin/images/placeholder-image.jpg') }}" /></label>
                                    </div>
                                    <input type="file" name="mobile_image" id="mobile_icon" accept="image/*" onchange="mobileloadIcon(event)" class="d-none">
                                    <p class="small text-muted">Click here to browse image</p>

                                    <script>
                                        let mobileloadIcon = function(event) {
                                            let mobileiconOutput = document.getElementById('mobileiconOutput');
                                            mobileiconOutput.src = URL.createObjectURL(event.target.files[0]);
                                            mobileiconOutput.onload = function() {
                                                URL.revokeObjectURL(mobileiconOutput.src) // free memory
                                            }
                                        };
                                    </script>
                                </div>
                                @error('mobile_image') <p class="small text-danger">{{ $message }}</p> @enderror
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <button type="submit" class="btn btn-sm btn-danger">Update</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
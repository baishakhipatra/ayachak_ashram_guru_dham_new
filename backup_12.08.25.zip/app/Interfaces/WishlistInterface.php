<?php

namespace App\Interfaces;

interface WishlistInterface 
{
    public function addToWishlist($productId);
    // public function viewByIp();
    // public function delete($id);
    // public function empty();
}
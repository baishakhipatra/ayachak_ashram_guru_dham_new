<?php

namespace App\Interfaces;

interface SaleInterface 
{
    /**
     * This method is to fetch list of all images from gallery
     */
    public function listAll();
}
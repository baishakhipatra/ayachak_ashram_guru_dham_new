<?php

namespace App\Interfaces;

interface SearchInterface 
{
    public function index(array $data);
}
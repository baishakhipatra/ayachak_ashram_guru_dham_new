<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FranchisePartner extends Model
{
    protected $table ='franchise_partners';
}

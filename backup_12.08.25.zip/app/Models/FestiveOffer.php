<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
class FestiveOffer extends Model
{
    protected $table = 'festive_offers';
	
	
}
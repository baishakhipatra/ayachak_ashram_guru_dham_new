<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CoziWhatsapp extends Model
{
    protected $table ="lux_cozi_whatsapp";

}

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use DB;
class FestiveOfferContent extends Model
{
    protected $table = 'festive_offer_contents';
	
	
}
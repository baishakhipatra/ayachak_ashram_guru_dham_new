<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CartOffer extends Model
{
    protected $table = 'cart_offers';
}
